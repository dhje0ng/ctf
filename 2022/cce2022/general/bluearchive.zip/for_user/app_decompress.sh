#!/bin/bash
tar xvf app.tar.xz