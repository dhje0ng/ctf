#!/bin/bash
service cron start
runuser -u node npm start
