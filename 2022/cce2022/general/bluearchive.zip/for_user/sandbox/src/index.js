const express = require('express')
const { encode } = require("html-entities");

const app = express()

app.get('/', function (req, res) {
    data = `<html>
<head><title>sandbox</title></head>
<body>
<script>
FLAG = "cce2022{this_is_not_real_flag}"
</script>
<iframe src="${encode(req.query.url)}" style="width: 100%; height: 100%; border: 0"></iframe>
</body>
</html>`
    res.setHeader("Content-Type","text/html").send(data);
})

app.listen(process.env.PORT);
